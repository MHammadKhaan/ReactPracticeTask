// InputComponent.js
import React, { useState } from "react";

function InputComponent() {
  const [inputValue, setInputValue] = useState("");

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  return (
    <div>
      <label>Input Field:</label>
      <input type="text" value={inputValue} onChange={handleInputChange} />
      <p>Typed Value: {inputValue}</p>
    </div>
  );
}

export default InputComponent;
