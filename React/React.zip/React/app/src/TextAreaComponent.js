// TextAreaComponent.js
import React, { useState } from "react";

function TextAreaComponent() {
  const [textValue, setTextValue] = useState("");

  const handleTextAreaChange = (e) => {
    setTextValue(e.target.value);
  };

  return (
    <div>
      <label>Textarea:</label>
      <textarea value={textValue} onChange={handleTextAreaChange}></textarea>
      <p>Typed Text: {textValue}</p>
    </div>
  );
}

export default TextAreaComponent;
