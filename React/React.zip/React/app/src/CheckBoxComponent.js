// CheckBoxComponent.js
import React, { useState } from "react";

function CheckBoxComponent() {
  const [isChecked, setIsChecked] = useState(false);

  const handleCheckBoxChange = () => {
    setIsChecked(!isChecked);
  };

  return (
    <div>
      <label>
        <input
          type="checkbox"
          checked={isChecked}
          onChange={handleCheckBoxChange}
        />
        Check me
      </label>
      <p>Checkbox is {isChecked ? "checked" : "unchecked"}</p>
    </div>
  );
}

export default CheckBoxComponent;
