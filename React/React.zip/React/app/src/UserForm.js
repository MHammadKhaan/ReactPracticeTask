import React, { useState } from "react";

const UserForm = (props) => {
  const { userName, userEmail, onUpdateUser } = props;

  // Local state to manage form input values
  const [name, setName] = useState(userName || "");
  const [email, setEmail] = useState(userEmail || "");

  // Event handlers for form input changes
  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  // Event handler for form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    // Updating the user information using the provided onUpdateUser prop
    onUpdateUser({
      name,
      email,
      
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Name:
        <input type="text" value={name} onChange={handleNameChange} />
      </label>
      <br />
      <label>
        Email:
        <input type="email" value={email} onChange={handleEmailChange} />
      </label>
      <br />
      <button type="submit">Update User</button>
    </form>
  );
};

export default UserForm;
