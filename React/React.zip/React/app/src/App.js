import logo from "./logo.svg";
import "./App.css";
import MyFormComponent from "./MyFormComponent";
import React, { useState } from "react";
import UserForm from "./UserForm";

function App() {
  const initialUser = {
    userName: "Mehtab",
    userEmail: "Mehtab98@gmail.com",
  };

  const [user, setUser] = useState(initialUser);

  // Function to update user information
  const updateUser = (newUserInfo) => {
    setUser({
      ...user,
      ...newUserInfo,
    });
  };

  return (
    <div className="App">
      <h1>
        {" "}
        ReactJS-Userdefined component/s, Props, Sate, Event Handling on Form
      </h1>
      <MyFormComponent />

      <hr />
      <div>
        <h1>User Information</h1>
        <p>Name: {user.userName}</p>
        <p>Email: {user.userEmail}</p>
        <hr />
        <h2>Edit User</h2>
        <UserForm
          userName={user.userName}
          userEmail={user.userEmail}
          onUpdateUser={updateUser}
        />
      </div>
    </div>
  );
}

export default App;
