// FormComponent.js
import React from "react";
import InputComponent from "./InputComponent";
import SelectComponent from "./SelectComponent";
import TextAreaComponent from "./TextAreaComponent";
import CheckBoxComponent from "./CheckBoxComponent";

function FormComponent() {
  return (
    <form>
      <InputComponent />
      <SelectComponent />
      <TextAreaComponent />
      <CheckBoxComponent />
    </form>
  );
}

export default FormComponent;
